import java.util.*;
class Prefixsum
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the size n");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("Enter the elements of the array of size n");
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
    int previous[]=new int[n];
    previous[0]=a[0];
    for(int i=1;i<n;i++)
    {
        previous[i]=previous[i-1]+a[i];
    }
for(int i=0;i<n;i++)
{
    System.out.println(previous[i]);
}
    }

}